#include	"includes.h"
#include	"timers.h"
#include	<delays.h>
#include 	"io_define.h"
#include	"adc/adc.h"
#include	<usart.h>
#include	<adc.h>

#define txtSensorA	"Sensor A: "
#define txtSensorB	"Sensor B: "
#define txtSensorC	"Sensor C: "
#define CRLF	"\r\n"

char CR = 0x0A;
char LF = 0x0D;

OS_STK	Start_TaskStk[100L];
OS_STK	Task1Stk[100L];
OS_STK	Task2Stk[100L];
OS_STK	Task3Stk[100L];
//OS_STK	Task4Stk[100L];
//OS_STK	Task5Stk[100L];

OS_EVENT *STask1;
OS_EVENT *STask2;
OS_EVENT *STask3;
//OS_EVENT *STask4;
//OS_EVENT *STask5;
OS_EVENT *QueueADC0;
OS_EVENT *QueueADC1;
OS_EVENT *QueueADC2;

void *QueueADC0Message[10];
void *QueueADC1Message[10];
void *QueueADC2Message[10];

void Task1(void *pdata)
{
	unsigned int ADC0Value;
	unsigned int ADC1Value;
	unsigned int ADC2Value;

#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
	char *err;
	for(;;)
	{

		OSSemPend(STask1,0,err);
		SetChanADC(ADC_CH0);
		Delay10TCYx( 100 );
		ConvertADC();
		while( BusyADC() );
		ADC0Value = ReadADC();
		SetChanADC(ADC_CH1);
		Delay10TCYx( 100 );
		ConvertADC();
		while( BusyADC() );
		ADC1Value = ReadADC();
		SetChanADC(ADC_CH2);
		Delay10TCYx( 100 );
		ConvertADC();
		while( BusyADC() );
		ADC2Value = ReadADC();
		salidaLED_2 = !(salidaLED_2);

		OSQPost(QueueADC0,ADC0Value);
		OSQPost(QueueADC1,ADC1Value);
		OSQPost(QueueADC2,ADC2Value);

		OSTimeDly(100);
		OSSemPost(STask2);
	}
}

void Task2(void *pdata)
{
	unsigned int ADC0Value = 0;
	unsigned int ADC1Value = 0;
	unsigned int ADC2Value = 0;

#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
	char *err;
	char value[10];
	
	for(;;)
	{
	
		OSSemPend(STask2,0,err);

		ADC0Value = (unsigned int) OSQPend(QueueADC0, 0, err);
		ADC1Value = (unsigned int) OSQPend(QueueADC0, 0, err);
		ADC2Value = (unsigned int) OSQPend(QueueADC0, 0, err);

		salidaLED_1 = !(salidaLED_1);
		putrsUSART(txtSensorA);
		sprintf(value,"%d",ADC0Value);
		putrsUSART(value);
		putrsUSART(CRLF);
		putrsUSART(txtSensorB);
		sprintf(value,"%d",ADC1Value);
		putrsUSART(value);
		putrsUSART(CRLF);
		putrsUSART(txtSensorC);
		sprintf(value,"%d",ADC2Value);
		putrsUSART(value);
		putrsUSART(CRLF);
		OSTimeDly(1000);
		OSSemPost(STask1);
	}
}

void Task3(void *pdata)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
	char *err;
	for(;;)
	{
		//OSSemPend(STask3,0,err);
		salidaLED_0 = !(salidaLED_0);
		//OSTimeDly(100);
		//salidaLED_0 = !(salidaLED_0);
		OSTimeDly(100);
		//OSSemPost(STask1);
	}
}

void Task4(void *pdata)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
	char *err;
	for(;;)
	{
		//OSSemPend(STask4,0,err);
		salidaLED_3 = !(salidaLED_3);
		OSTimeDly(100);
		//OSSemPost(STask5);
	}
}

void Task5(void *pdata)
{
#if OS_CRITICAL_METHOD == 3                      /* Allocate storage for CPU status register           */
    OS_CPU_SR  cpu_sr;
#endif
	char *err;
	for(;;)
	{
		//OSSemPend(STask5,0,err);
		salidaLED_4 = !(salidaLED_4);
		OSTimeDly(100);
		//OSSemPost(STask1);
	}
}

//---------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------
void Task_START(void *pdata)
{
	int		i_data;

	ADC_Init();
	// enable interrupts
	OpenTimer0(TIMER_INT_ON & T0_16BIT & T0_SOURCE_INT & T0_PS_1_1);

	OpenUSART( USART_TX_INT_OFF &
 				USART_RX_INT_OFF &
 				USART_ASYNCH_MODE &
 				USART_EIGHT_BIT &
 				USART_CONT_RX &
 				USART_BRGH_LOW,
 			12 );

	OpenADC( ADC_FOSC_8 &
		ADC_RIGHT_JUST &
		ADC_12_TAD,
		ADC_CH11 &
		ADC_INT_OFF, 12 );

	TRISA |= 0b00001110;
	ADCON1 &= 0b00001100;

	
/*
	OSSemPend(STask2,0,NULL);
	OSSemPend(STask3,0,NULL);
	OSSemPend(STask4,0,NULL);
	OSSemPend(STask5,0,NULL);
*/
	OSSemPost(STask1);

	OSTaskCreate(Task1, (void *)0, &Task1Stk[0], 5);
	OSTaskCreate(Task2, (void *)0, &Task2Stk[0], 4);
	OSTaskCreate(Task3, (void *)0, &Task3Stk[0], 3);
	//OSTaskCreate(Task4, (void *)0, &Task4Stk[0], 2);
	//OSTaskCreate(Task5, (void *)0, &Task5Stk[0], 1);

	i_data = *((int *)pdata);

	// task loop
	for(;;)
	{
		OSTimeDly(100);
	}
}


//-----------------------------------------------------------------------------------------------------------------------
void main (void)
{
	int i_test = 0xABCD;

	/* Set oscilator to 16Mhz */
	OSCCON = 0b01111110;
	TRISD = 0b00000000;
	salidaLED_0 = 0;
	salidaLED_1 = 0;
	salidaLED_2 = 0;
	salidaLED_3 = 0;
	salidaLED_4 = 0;
	salidaLED_5 = 0;
	//resistencias de pull - up  DESCONECTADAS (RBPU)
	//INTCON2 = 0b10000000;
 	//INTCON2|=0x80;

	INTCONbits.GIEH = 0;

	OSInit();

	STask1  = OSSemCreate(0);
	STask2  = OSSemCreate(0);
	STask3  = OSSemCreate(0);
	//STask4  = OSSemCreate(0);
	//STask5  = OSSemCreate(0);

	QueueADC0 = OSQCreate(QueueADC0Message,10);
	QueueADC1 = OSQCreate(QueueADC1Message,10);
	QueueADC2 = OSQCreate(QueueADC2Message,10);

	OSTaskCreate(Task_START, (void *)&i_test, &Start_TaskStk[0], 0);
	OSStart();
}
