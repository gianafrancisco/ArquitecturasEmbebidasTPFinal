#ifndef __MY_ADC__
#define __MY_ADC__

void Timer0_Init(void);
void ADC_Init(void);
unsigned char ADC_Convert(void);

#endif

